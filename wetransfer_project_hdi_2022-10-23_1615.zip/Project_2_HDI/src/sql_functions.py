
from sqlalchemy import create_engine

# Test Connection
host_name='localhost'
user_name='hdi'
user_password='hdi'
database='sustainable_development'

def get_connection():
    connection = create_engine("mysql+pymysql://{user}:{pw}@{host}"
				.format(host=host_name, user=user_name, pw=user_password))
    return connection
    
def create_database(database_name):
    connection= get_connection()
    create_query =f'CREATE DATABASE IF NOT EXISTS {database_name};'
    connection.execute(create_query)